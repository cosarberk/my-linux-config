#!/bin/bash
asusctl aura --next-mode
notify-send "Keyboard LED" "Mode changed"
